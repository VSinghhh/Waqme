

#import <UIKit/UIKit.h>

#import "MBProgressHUD.h"

@interface HomeViewController : UIViewController<UIWebViewDelegate>
{
    
}

@property (nonatomic,retain)MBProgressHUD* indicatorView;
@end
