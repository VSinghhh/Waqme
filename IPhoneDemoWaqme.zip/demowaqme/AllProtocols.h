//
//  AllProtocols.h
//  goldgym
//
//  Created by Bilal M.tahir on 14/04/2014.
//  Copyright (c) 2014 M.tahir. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HomeViewController.h"


#define ENABLE_LOG

#ifdef ENABLE_LOG
#define NSLog(...)
#endif

